import { getApiUrl } from '../config/api';

const BROKEN_ASSET_PREFIXES = ['/src/assets/', 'src/assets/'];

export function isValidLatitude(value: number): boolean {
  return Number.isFinite(value) && value >= -90 && value <= 90;
}

export function isValidLongitude(value: number): boolean {
  return Number.isFinite(value) && value >= -180 && value <= 180;
}

/**
 * Converts stored image paths, relative API paths, and absolute URLs into a
 * browser-loadable URL. Returns null for known-broken Vite source paths.
 */
export function resolveMediaUrl(raw?: string | null): string | null {
  if (!raw) return null;
  const value = String(raw).trim();
  if (!value) return null;

  if (BROKEN_ASSET_PREFIXES.some((prefix) => value.startsWith(prefix))) {
    return null;
  }

  if (value.startsWith('blob:') || value.startsWith('data:')) {
    return value;
  }

  if (/^https?:\/\//i.test(value)) {
    return value;
  }

  if (value.startsWith('/api/')) {
    return getApiUrl(value);
  }

  const withoutLeadingSlash = value.replace(/^\/+/, '').replace(/\\/g, '/');
  if (withoutLeadingSlash.startsWith('uploads/')) {
    return getApiUrl(`/api/${withoutLeadingSlash}`);
  }
  if (withoutLeadingSlash.startsWith('api/')) {
    return getApiUrl(`/${withoutLeadingSlash}`);
  }

  return getApiUrl(`/${withoutLeadingSlash}`);
}

export function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('Could not encode image evidence'));
    };
    reader.onerror = () => reject(reader.error || new Error('Could not read image evidence'));
    reader.readAsDataURL(blob);
  });
}

export async function uploadEvidenceFile(
  source: Blob | File,
  filename = 'complaint.jpg'
): Promise<{ url: string; path: string } | null> {
  const formData = new FormData();
  const name = source instanceof File ? source.name || filename : filename;
  formData.append('image', source, name);

  const response = await fetch(getApiUrl('/api/evidence'), {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`Evidence upload failed (HTTP ${response.status})`);
  }

  const json = await response.json();
  const url = typeof json.url === 'string' ? json.url : null;
  const path = typeof json.path === 'string' ? json.path : url;
  if (!url) return null;
  return { url, path };
}

/**
 * Persist a complaint photograph so it remains visible after refresh.
 * Prefers the backend upload store; falls back to a data URL of the same photo.
 */
export async function persistEvidenceSource(
  source: Blob | File | string | null | undefined,
  filename?: string
): Promise<string | null> {
  if (!source) return null;

  if (typeof source === 'string') {
    const resolved = resolveMediaUrl(source);
    if (resolved && !resolved.startsWith('blob:')) {
      return resolved;
    }
    if (source.startsWith('blob:') || source.startsWith('data:')) {
      const res = await fetch(source);
      const blob = await res.blob();
      return persistEvidenceSource(blob, filename);
    }
    return resolved;
  }

  try {
    const uploaded = await uploadEvidenceFile(source, filename);
    if (uploaded?.url) return uploaded.url;
  } catch (err) {
    console.warn('Could not upload evidence to backend; storing encoded photograph locally.', err);
  }

  return blobToDataUrl(source);
}
