import React, { useEffect, useState } from 'react';
import { ImageOff, Loader2 } from 'lucide-react';
import { resolveMediaUrl } from '../../services/media';

interface EvidenceImageProps {
  src?: string | null;
  alt: string;
  className?: string;
  imgClassName?: string;
}

export const EvidenceImage: React.FC<EvidenceImageProps> = ({
  src,
  alt,
  className = '',
  imgClassName = 'w-full h-full object-cover',
}) => {
  const resolved = resolveMediaUrl(src);
  const [status, setStatus] = useState<'loading' | 'loaded' | 'error'>(resolved ? 'loading' : 'error');

  useEffect(() => {
    setStatus(resolved ? 'loading' : 'error');
  }, [resolved]);

  if (!resolved || status === 'error') {
    return (
      <div
        className={`flex flex-col items-center justify-center gap-1.5 bg-slate-950 text-slate-400 border border-slate-800 px-3 py-6 text-center ${className}`}
        role="img"
        aria-label="Photographic evidence could not be loaded"
      >
        <ImageOff className="w-6 h-6 text-slate-500" />
        <span className="text-xs font-medium text-slate-300">Photograph unavailable</span>
        <span className="text-[11px] text-slate-500 max-w-[220px]">
          The uploaded pothole image could not be loaded. The file may be missing or the saved path is no longer valid.
        </span>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      {status === 'loading' && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-1.5 bg-slate-950/80 text-slate-300">
          <Loader2 className="w-5 h-5 animate-spin text-amber-400" />
          <span className="text-[11px] font-medium">Loading photograph…</span>
        </div>
      )}
      <img
        src={resolved}
        alt={alt}
        className={imgClassName}
        onLoad={() => setStatus('loaded')}
        onError={() => setStatus('error')}
      />
    </div>
  );
};
