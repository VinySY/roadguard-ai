import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Check, Loader2, MapPin, X } from 'lucide-react';
import { LocationCoordinates } from '../../types';
import { DEFAULT_MUNICIPAL_CENTER, reverseGeocode } from '../../services/location';
import { isValidLatitude, isValidLongitude } from '../../services/media';

interface LocationPinPickerProps {
  isOpen: boolean;
  initialLocation?: LocationCoordinates | null;
  onConfirm: (coords: LocationCoordinates) => void;
  onCancel: () => void;
}

const STREETS_TILES = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

function pinIcon() {
  return L.divIcon({
    className: 'roadguard-temp-pin',
    html: `
      <div style="position:relative;width:28px;height:40px;">
        <div style="width:28px;height:28px;border-radius:50% 50% 50% 0;background:#f59e0b;transform:rotate(-45deg);border:2px solid #0f172a;box-shadow:0 4px 10px rgba(0,0,0,.35);"></div>
        <div style="position:absolute;top:7px;left:7px;width:14px;height:14px;border-radius:999px;background:#0f172a;"></div>
      </div>
    `,
    iconSize: [28, 40],
    iconAnchor: [14, 38],
  });
}

export const LocationPinPicker: React.FC<LocationPinPickerProps> = ({
  isOpen,
  initialLocation,
  onConfirm,
  onCancel,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);

  const [draft, setDraft] = useState<{ lat: number; lng: number } | null>(null);
  const [addressLabel, setAddressLabel] = useState<string>('');
  const [geocoding, setGeocoding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const start = initialLocation && isValidLatitude(initialLocation.lat) && isValidLongitude(initialLocation.lng)
      ? { lat: initialLocation.lat, lng: initialLocation.lng }
      : null;

    setDraft(start);
    setAddressLabel(start ? (initialLocation?.address || initialLocation?.street || '') : '');
    setError(null);

    const timer = window.setTimeout(() => {
      if (!mapContainerRef.current || mapRef.current) return;

      const center = start || DEFAULT_MUNICIPAL_CENTER;
      const map = L.map(mapContainerRef.current, {
        center: [center.lat, center.lng],
        zoom: start ? 17 : 13,
        zoomControl: true,
      });

      L.tileLayer(STREETS_TILES, {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(map);

      mapRef.current = map;

      const placeMarker = (lat: number, lng: number) => {
        if (markerRef.current) {
          markerRef.current.setLatLng([lat, lng]);
        } else {
          const marker = L.marker([lat, lng], { icon: pinIcon(), draggable: true }).addTo(map);
          marker.on('dragend', () => {
            const pos = marker.getLatLng();
            setDraft({ lat: pos.lat, lng: pos.lng });
          });
          markerRef.current = marker;
        }
      };

      if (start) {
        placeMarker(start.lat, start.lng);
      }

      map.on('click', (event: L.LeafletMouseEvent) => {
        const { lat, lng } = event.latlng;
        setDraft({ lat, lng });
        placeMarker(lat, lng);
      });

      map.invalidateSize();
    }, 50);

    return () => {
      window.clearTimeout(timer);
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
      markerRef.current = null;
    };
  }, [isOpen, initialLocation]);

  useEffect(() => {
    if (!draft) return;
    let cancelled = false;
    setGeocoding(true);
    reverseGeocode(draft.lat, draft.lng)
      .then((geo) => {
        if (cancelled) return;
        setAddressLabel(geo.address || [geo.street, geo.area, geo.city].filter(Boolean).join(', '));
      })
      .finally(() => {
        if (!cancelled) setGeocoding(false);
      });
    return () => {
      cancelled = true;
    };
  }, [draft?.lat, draft?.lng]);

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (!draft || !isValidLatitude(draft.lat) || !isValidLongitude(draft.lng)) {
      setError('Click the map to place a pin on the exact pothole location.');
      return;
    }

    onConfirm({
      lat: Number(draft.lat.toFixed(7)),
      lng: Number(draft.lng.toFixed(7)),
      address: addressLabel || undefined,
      street: addressLabel.split(',')[0]?.trim() || `Pinned ${draft.lat.toFixed(5)}, ${draft.lng.toFixed(5)}`,
      area: 'Selected on map',
    });
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="w-full max-w-3xl bg-slate-900 border border-amber-500/40 rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh]">
        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between bg-amber-500/10">
          <div>
            <h3 className="text-sm font-semibold text-amber-300 flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Pin selection mode
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Click the road where the pothole is. Drag the pin to adjust. Map navigation still works with pinch/scroll.
            </p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800"
            aria-label="Cancel pin selection"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative">
          <div ref={mapContainerRef} className="w-full h-[52vh] min-h-[280px] cursor-crosshair" />
          <div className="absolute top-3 left-3 right-3 pointer-events-none">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-950/90 border border-amber-500/40 text-[11px] text-amber-300 font-medium">
              Selection mode: tap the exact road location
            </div>
          </div>
        </div>

        <div className="p-4 space-y-3 border-t border-slate-800">
          {draft ? (
            <div className="text-xs text-slate-200 space-y-1">
              <div className="font-mono text-amber-400">
                {draft.lat.toFixed(6)}°, {draft.lng.toFixed(6)}°
              </div>
              <div className="text-slate-400 min-h-[1.25rem]">
                {geocoding ? 'Looking up nearby address…' : addressLabel || 'Address lookup optional — coordinates will still be saved.'}
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-400">No pin yet. Click the map to drop a temporary marker.</p>
          )}

          {error && <p className="text-xs text-rose-400">{error}</p>}

          <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirm}
              disabled={!draft}
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {geocoding ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              Confirm location
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
